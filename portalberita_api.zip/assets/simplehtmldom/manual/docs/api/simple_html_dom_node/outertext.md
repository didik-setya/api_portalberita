# outertext

```php
outertext ( ) : string
```

Returns the outer text (everything including the opening and closing tags) of the current node.